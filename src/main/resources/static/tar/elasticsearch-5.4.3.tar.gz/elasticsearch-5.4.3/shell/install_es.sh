#!/bin/bash
# Get ElasticSearch and configure it.

# Location是ElasticSearch在Tomcat中的地址
LOCATION=$1
CLUSTERNAME=$2
NODENAME=$3
TCPPORT=$4
HTTPPORT=$5
MEMORY=$6
MASTER=$7
DATA=$8
PUBLICHOST=$9
UNICASTHOST=${10}

# 配置ElasticSearch运行环境
if [ ! -f "/tmp/elasticsearch_env.log" ]; then
    touch "/tmp/elasticsearch_env.log"

    echo "" >> /etc/sysctl.conf
    echo "# ==== 设置Linux的ElasticSearch环境 ====" >> /etc/sysctl.conf
    echo "vm.max_map_count=262144" >> /etc/sysctl.conf
    echo "fs.file-max=65536"       >> /etc/sysctl.conf
    # vm.swappiness=1 Linux正常情况下不进行交换，仅当出现紧急情况
    echo "vm.swappiness=1"         >> /etc/sysctl.conf
    sysctl -p  > /dev/null 2>&1

    # 创建系统用户
    if ! id -u elasticsearch >> /tmp/elasticsearch_env.log 2>&1 ; then
        groupadd elasticsearch
        useradd  -g elasticsearch elasticsearch
    fi

    # Linux设置
    echo "elasticsearch soft nofile 65536"      >> /etc/security/limits.conf
    echo "elasticsearch hard nofile 65536"      >> /etc/security/limits.conf
    echo "elasticsearch soft memlock unlimited" >> /etc/security/limits.conf
    echo "elasticsearch hard memlock unlimited" >> /etc/security/limits.conf

    # 安装lsof和netstat
    if which yum 2>/dev/null; then
        yum -y install java        >> /tmp/elasticsearch_env.log 2>&1
        yum -y install lsof        >> /tmp/elasticsearch_env.log 2>&1
        yum -y install netstat     >> /tmp/elasticsearch_env.log 2>&1
    else
        apt-get -y install java    >> /tmp/elasticsearch_env.log 2>&1
        apt-get -y install lsof    >> /tmp/elasticsearch_env.log 2>&1
        apt-get -y install netstat >> /tmp/elasticsearch_env.log 2>&1
    fi


    echo "configure environment successfully on /etc/sysctl.conf"          >> /tmp/elasticsearch_env.log
    echo "configure environment successfully on /etc/security/limits.conf" >> /tmp/elasticsearch_env.log
fi


# 创建系统用户
if ! id -u elasticsearch >/dev/null 2>&1 ; then
  groupadd elasticsearch
  useradd  -g elasticsearch elasticsearch
fi

ES_DIR=/usr/elasticsearch/es$TCPPORT
LOG=$ES_DIR/install.log
mkdir -p $ES_DIR
touch $LOG
cp -r $LOCATION/* $ES_DIR  >> $LOG 2>&1
chown -R elasticsearch:elasticsearch /usr/elasticsearch  >> $LOG 2>&1

ES_CONFIG=$ES_DIR/config/elasticsearch.yml
# 配置ElasticSearch
echo "# ==== Elasticsearch Configuration ====" > $ES_CONFIG
echo "cluster.name: $CLUSTERNAME" >> $ES_CONFIG
echo "node.name: $NODENAME"       >> $ES_CONFIG
echo "node.master: $MASTER" >> $ES_CONFIG
echo "node.data: $DATA"       >> $ES_CONFIG
echo "path.data: $ES_DIR/data"     >> $ES_CONFIG
echo "path.logs: $ES_DIR/logs"     >> $ES_CONFIG
echo "bootstrap.memory_lock: true" >> $ES_CONFIG
echo "network.publish_host: $PUBLICHOST"      >> $ES_CONFIG
echo "network.host: 0.0.0.0"      >> $ES_CONFIG
echo "http.port: $HTTPPORT"            >> $ES_CONFIG
echo "transport.tcp.port: $TCPPORT" >> $ES_CONFIG
echo "http.enabled: yes" >> $ES_CONFIG
echo "discovery.zen.minimum_master_nodes: 1" >> $ES_CONFIG
echo "discovery.zen.ping_timeout: 5s" >> $ES_CONFIG
# echo "discovery.zen.ping.multicast.enabled: false" >> $ES_CONFIG
echo "action.destructive_requires_name: true" >> $ES_CONFIG
echo "discovery.zen.ping.unicast.hosts: $UNICASTHOST" >> $ES_CONFIG
echo "" >> $ES_CONFIG
echo "" >> $ES_CONFIG

# 配置JVM内存
JVM_CONFIG=$ES_DIR/config/jvm.options
echo "-Xms$MEMORY" >> $JVM_CONFIG
echo "-Xmx$MEMORY" >> $JVM_CONFIG

chown -R elasticsearch:elasticsearch /usr/elasticsearch  >> $LOG 2>&1
chmod a+x $ES_DIR/bin/*


