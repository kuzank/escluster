#! /bin/sh

TCP_PORT=$1
portResult=$(ps aux | grep elasticsearch | grep $TCP_PORT | awk '{ print $2; }')

if [[ $portResult == "" ]]
then
    echo "NONE"
else
    ARRAY=($portResult)
    for i in ${ARRAY[@]}
    do
        kill -9 $i
        echo "SUCCESS"
    done
fi

