#! /bin/bash

TCP_PORT=$1
su elasticsearch -c "/usr/elasticsearch/es$TCP_PORT/bin/elasticsearch -d"

